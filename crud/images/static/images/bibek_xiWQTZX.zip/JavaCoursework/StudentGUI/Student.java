 
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Student {
    //instance variable
     private int enrollmentID;
     private String courseName = "";
    private String dateOfBirth;
    private int tuitionFee;
    private String studentName;
    private String dateOfEnrollment = "";
    private int courseDuration;
    
   
     //creating constructors
    public Student(String dateOfBirth, String studentName, int courseDuration, int tuitionFee)
    {
        this.dateOfBirth = dateOfBirth;
        this.studentName = studentName;
        this.courseDuration = courseDuration;
        this.tuitionFee = tuitionFee;
        this.courseName = "";
        this.enrollmentID = 0;
        this.dateOfEnrollment = "";
    
    }
      //getter methods for EnrollmentID
    public int getEnrollmentID() {
        return enrollmentID;
    }
     //setter method value for EnrollmentID
    public void setEnrollmentID(int enrollmentID) {
        this.enrollmentID = enrollmentID;
    }
     //getter methods for DateOfBirth
    public String getDateOfBirth() {
        return dateOfBirth;
    }
    //setter method value for DateOfBirth
    public void setDateOfBirth(String dateOfBirth){
        this.dateOfBirth = dateOfBirth;
    }
      //getter methods for CourseName
    public String getCourseName() {
        return courseName;
    }
      //setter methods value for CourseName
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

     //getter methods for StudentName
    public String getStudentName() {
        return studentName;
    }
    //setter methods for StudentName
    public void setStudentName(String studentName){
        this.studentName = studentName;
    }
     //getter methods for DateOfEnrollment
    public String getDateOfEnrollment() {
        return dateOfEnrollment;
    }
        //setter methods for DateOfEnrollment
    public void setDateOfEnrollment(String dateOfEnrollment) {
        this.dateOfEnrollment = dateOfEnrollment;
    }
      //getter methods for CourseDuration
    public int getCourseDuration() {
         return courseDuration;
    }
    //setter methods for CourseDuration
     public void setCourseDuration(int courseDuration){
        this.courseDuration = courseDuration;
    }
     //getter methods for TuitionFee
    public int getTuitionFee() {
        return tuitionFee;
    }
    //setter methods for TuitionFee
    public void setTuitionFee(int TuitionFee){
        this.tuitionFee = tuitionFee;
    }
    
    // Displaying values in conditional statement
    public void display()
    {
        if(enrollmentID == 0 || dateOfBirth.equals("") || courseDuration == 0 || studentName.equals("")
         || courseName.equals("") || dateOfEnrollment.equals("") || tuitionFee == 0)
         //Conditional Statement 
         {
             System.out.println("No records for student found");
         }
         else
         {
             System.out.println("Enrollment Id : " + enrollmentID);  
             System.out.println("Date OF Birth : " + dateOfBirth); 
             System.out.println("Course Name : " + courseName); 
             System.out.println("Student Name : " + studentName);
             System.out.println("Date Of Enrollment : " + dateOfEnrollment); 
             System.out.println("Course Duration : " + courseDuration);
               System.out.println("Tution Fee : " + tuitionFee);
         }
    }
}


