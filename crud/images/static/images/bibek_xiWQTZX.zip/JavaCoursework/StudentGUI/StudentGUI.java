
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class StudentGUI {
    private  ArrayList<Student> students = new ArrayList<Student>();
    private final static int INVALID = -1; 

    private JFrame frame1;
    private JFrame frame2;
    private JFrame frame3;

    private JLabel enrollmentLabel;
    private JLabel coursedurationLabel;
    private JLabel daypresentLabel;
    private JLabel courseNameLabel;
    private JLabel enrolledLabel;
    private JLabel tuitionLabel;
    private JLabel birthLabel;
    private JLabel credithourLabel;
    private JLabel moduleLabel;
    private JLabel dropdateLabel;
    private JLabel studentnameLabel;
    private JLabel remainingmoduleLabel;
    private JLabel monthattendLabel;

    private JTextField idField;
    private JTextField idPField;
    private JTextField idGField;
    private JTextField nameField;
    private JTextField numOfModuleField;
    private JTextField courseNameGField;
    private JTextField dayPresentField1;
    private JTextField courseNameField;
    private JTextField dayPresentPField;
    private JTextField idBField;
    private JTextField numMonthAttendField;
    private JTextField courseDurationField;
    private JTextField remainingMOdyleField;
    private JTextField tuitonField;
    private JTextField creditHourField;
    private JTextField idREField;

    private JComboBox<String> enrollMonthG;
    private JComboBox<String> enrollDayG;
    private JComboBox<String> dropYear;
    private JComboBox<String> enrollDay;
    private JComboBox<String> dropDay;
    private JComboBox<String> birthDay;
    private JComboBox<String> dropMonth;
    private JComboBox<String> enrollMonth;
    private JComboBox<String> birthMonth;
    private JComboBox<String> enrollYearG;
    private JComboBox<String> birthYear;
    private JComboBox<String> enrollYear;

    private JButton goToDropout;
    private JButton goToRegular;
    private JButton buttonRegular;
    private JButton paybillButton;
    private JButton buttonDropout;
    private JButton displayD;
    private JButton percentageButton;
    private JButton removestudentButton;
    private JButton clearButton2;
    private JButton grantCertificateButton;
    private JButton displayR;
    private JButton clearButton3;
    


    public StudentGUI()
    {

        String[] boxYear = {"Year","1998","1999","2000","2001","2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"};
        String[] boxMonth = {"Month","Jan", "Feb", "March", "April","May", "June", "July","Aug","sep","oct","Nov", "Dec"};
        String[] boxDay = {"Day","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
        
        //Frame
        frame1 = new JFrame();
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.getContentPane().setBackground(Color.BLUE);
        frame1.setLayout(null);
        frame1.setTitle("Student Form");
        frame1.setSize(600, 350);
        frame1.setLocation(500, 5);
       
        //Label
        enrollmentLabel = new JLabel("Enrollment id ");
        enrollmentLabel.setBounds(150, 20, 80, 30);
        enrollmentLabel.setFont(new Font(null, 0, 13));
        frame1.add(enrollmentLabel);

        idField = new JTextField();
        idField.setBounds(280, 20, 215, 30);
        frame1.add(idField);

        studentnameLabel = new JLabel("Student name ");
        studentnameLabel.setBounds(150, 60, 90, 30);
        studentnameLabel.setFont(new Font(null, 0, 13));
        frame1.add(studentnameLabel);

        nameField = new JTextField();
        nameField.setBounds(280, 60, 215, 30);
        frame1.add(nameField);

        birthLabel = new JLabel("DOB");
        birthLabel.setBounds(150, 95, 30, 30);
        birthLabel.setFont(new Font(null,0, 13));
        frame1.add(birthLabel);

        birthYear = new JComboBox<String>(boxYear);
        birthYear.setBounds(280, 95, 60, 30);
        frame1.add(birthYear);

        birthMonth = new JComboBox<String>(boxMonth);
        birthMonth.setBounds(350, 95, 70, 30);
        frame1.add(birthMonth);

        birthDay = new JComboBox<String>(boxDay);
        birthDay.setBounds(430, 95, 60, 30);
        frame1.add(birthDay);

        courseNameLabel = new JLabel("Course name ");
        courseNameLabel.setBounds(150, 135, 90, 30);
        courseNameLabel.setFont(new Font(null,0, 13));
        frame1.add(courseNameLabel);

        courseNameField = new JTextField();
        courseNameField.setBounds(280, 135, 215, 30);
        frame1.add(courseNameField);

        coursedurationLabel = new JLabel("Course duration ");
        coursedurationLabel.setBounds(150, 175, 95, 30);
        coursedurationLabel.setFont(new Font(null,0, 13));
        frame1.add(coursedurationLabel);

        courseDurationField = new JTextField();
        courseDurationField.setBounds(280, 175, 215, 30);
        frame1.add(courseDurationField);

        enrolledLabel = new JLabel("DOE ");
        enrolledLabel.setBounds(150, 215, 35, 30);
        enrolledLabel.setFont(new Font(null,0, 13));
        frame1.add(enrolledLabel);

        enrollYear = new JComboBox<String>(boxYear);
        enrollYear.setBounds(280, 215, 60, 30);
        frame1.add(enrollYear);

        enrollMonth = new JComboBox<String>(boxMonth);
        enrollMonth.setBounds(350, 215, 70, 30);
        frame1.add(enrollMonth);
        enrollDay = new JComboBox<String>(boxDay);
        enrollDay.setBounds(430, 215, 60, 30);
        frame1.add(enrollDay);

        tuitionLabel = new JLabel("Tuition fee ");
        tuitionLabel.setBounds(150, 255, 90, 30);
        tuitionLabel.setFont(new Font(null,0, 13));
        frame1.add(tuitionLabel);

        tuitonField = new JTextField();
        tuitonField.setBounds(280, 255, 215, 30);
        frame1.add(tuitonField);

        goToRegular = new JButton("Regular ");
        goToRegular.setBounds(10, 215, 90, 30);
        frame1.add(goToRegular);
        goToRegular.setEnabled(false);

        makeRegular();

        goToRegular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                makeRegular();
                frame3.dispose();
            }
        });

        goToDropout = new JButton("Dropout");
        goToDropout.setBounds(10, 270, 90, 30);
        frame1.add(goToDropout);

        goToDropout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                makeDropout();
                frame2.dispose();
                goToRegular.setEnabled(true);
            }
        });
    }

    public void makeRegular()
    {
        String[] boxYear = {"Year","1998","1999","2000","2001","2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"};
        String[] boxMonth = {"Month","Jan", "Feb", "March", "April","May", "June", "July","Aug","sep","oct","Nov", "Dec"};
        String[] boxDay = {"Day","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};

        frame2 = new JFrame("Regular ");
        frame2.getContentPane().setBackground(Color.BLUE);
        frame2.setLayout(null);
        frame2.setSize(600, 450);
        frame2.setLocation(500, 350);

        credithourLabel = new JLabel("Credit Hour ");
        credithourLabel.setBounds(5, 05, 70, 30);
        credithourLabel.setFont(new Font(null, 0, 13));
        frame2.add(credithourLabel);

        creditHourField = new JTextField();
        creditHourField.setBounds(80, 05, 150, 30);
        frame2.add(creditHourField);

        daypresentLabel = new JLabel("Day Present ");
        daypresentLabel.setBounds(5, 50, 75, 30);//Kata rakhne fix garxa
        daypresentLabel.setFont(new Font(null, 0, 13));//Font size set Garxa//label ko color
        frame2.add(daypresentLabel);//panel ma add g

        dayPresentField1 = new JTextField();
        dayPresentField1.setBounds(80, 50, 150, 30);
        frame2.add(dayPresentField1);

        moduleLabel = new JLabel("Num module ");
        moduleLabel.setBounds(5, 90, 75, 30);
        moduleLabel.setFont(new Font(null, 0, 13));
        frame2.add(moduleLabel);

        numOfModuleField = new JTextField();
        numOfModuleField.setBounds(80,90,150,30);
        frame2.add(numOfModuleField);

        enrollmentLabel = new JLabel("Enrollment id ");
        enrollmentLabel.setBounds(325, 05, 100, 30);
        enrollmentLabel.setFont(new Font(null, 0, 13));
        frame2.add(enrollmentLabel);

        idPField = new JTextField();
        idPField.setBounds(415, 05, 150, 30);
        frame2.add(idPField);

        daypresentLabel = new JLabel("Day Present ");
        daypresentLabel.setBounds(325, 80, 75, 30);
        daypresentLabel.setFont(new Font(null, 0, 13));
        frame2.add(daypresentLabel);

        dayPresentPField = new JTextField();
        dayPresentPField.setBounds(415, 80, 150, 30);
        frame2.add(dayPresentPField);

        percentageButton = new JButton("Percentage ");
        percentageButton.setBounds(380, 150, 130, 30);
        frame2.add(percentageButton);
        percentageButton.setEnabled(false);

        JLabel line = new JLabel();
        line.setText("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        line.setBounds(0, 190, 600, 10);
        frame2.add(line);

        enrollmentLabel = new JLabel("Enrollment id ");
        enrollmentLabel.setBounds(5, 240, 80, 30);
        enrollmentLabel.setFont(new Font(null, 0, 13));
        frame2.add(enrollmentLabel);

        idGField = new JTextField();
        idGField.setBounds(85, 240, 180, 30);
        frame2.add(idGField);

        courseNameLabel = new JLabel("Course name ");
        courseNameLabel.setBounds(300, 240, 90, 30);
        courseNameLabel.setFont(new Font(null,0, 13));
        frame2.add(courseNameLabel);

        courseNameGField = new JTextField();
        courseNameGField.setBounds(385, 240, 180, 30);
        frame2.add(courseNameGField);

        enrolledLabel = new JLabel("DOE ");
        enrolledLabel.setBounds(5, 290, 35, 30);
        enrolledLabel.setFont(new Font(null,0, 13));
        frame2.add(enrolledLabel);

        enrollYearG = new JComboBox<String>(boxYear);
        enrollYearG.setBounds(85, 290, 60, 30);
        frame2.add(enrollYearG);

        enrollMonthG = new JComboBox<String>(boxMonth);
        enrollMonthG.setBounds(155, 290, 70, 30);
        frame2.add(enrollMonthG);
        enrollDayG = new JComboBox<String>(boxDay);
        enrollDayG.setBounds(235, 290, 60, 30);
        frame2.add(enrollDayG);

        grantCertificateButton = new JButton("Certificate ");
        grantCertificateButton.setBounds(20, 340, 100, 30);
        frame2.add(grantCertificateButton);
        grantCertificateButton.setEnabled(false);

        displayR = new JButton("Display ");
        displayR.setBounds(300, 340, 90, 30);
        frame2.add(displayR);
        displayR.setEnabled(false);

        clearButton2 = new JButton("Clear");
        clearButton2.setBounds(400, 340, 90, 30);
        frame2.add(clearButton2);

        buttonRegular = new JButton("Regular Add");//Regular add garnye button
        buttonRegular.setBounds(5, 150, 130, 30);
        frame2.add(buttonRegular);
        buttonRegular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentid();
                String name = getStudentname();
                String course = getCoursename();
                int courseduration = getCourseduration();
                double tuition = getTuitionFee();
                int credit = getCreditHours();
                int module = getNumModule();
                int boxDay = getDaypresent();
                String date = getDateOfBirth();
                String date2 = getDateOfEnrollment();
                if(name.isEmpty()){
                    JOptionPane.showMessageDialog(frame1," student name Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(course.isEmpty()){
                   JOptionPane.showMessageDialog(frame1," Course name Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
               
                else if (tuition == -202){
                    JOptionPane.showMessageDialog(frame1," Tuition Fee Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (courseduration == -202){
                    JOptionPane.showMessageDialog(frame1," Course Duration Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (credit == -202){
                    JOptionPane.showMessageDialog(frame1," Credit Hour Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (module == -202){
                    JOptionPane.showMessageDialog(frame1," Number Module Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (boxDay == -202){
                    JOptionPane.showMessageDialog(frame1," Present Day Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (id == INVALID || courseduration == INVALID || tuition == INVALID || credit == INVALID || boxDay == INVALID || module == INVALID ){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(date.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," DOb Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(date2.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," DOe  Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else{
                    boolean check = getCheckEnrollmentId(id);

                    if(check == false){
                        students.add(new Regular(id, course, course, name, course, courseduration, courseduration, module, credit, boxDay));
                        JOptionPane.showMessageDialog(frame1," Student Added.","Information",JOptionPane.INFORMATION_MESSAGE);
                        grantCertificateButton.setEnabled(true);
                        displayR.setEnabled(true);
                        percentageButton.setEnabled(true);
                        idField.setText("");
                        nameField.setText("");
                        courseNameField.setText("");
                        courseDurationField.setText("");
                        tuitonField.setText("");
                        dayPresentField1.setText("");
                        numOfModuleField.setText("");
                        creditHourField.setText("");
                        birthYear.setSelectedItem("Year");
                        birthMonth.setSelectedItem("Month");
                        birthDay.setSelectedItem("Day");
                        enrollYear.setSelectedItem("year");
                        enrollMonth.setSelectedItem("Month");
                        enrollDay.setSelectedItem("Day");
                        return;
                    }
                    else{
                        JOptionPane.showMessageDialog(frame1," Please Enter Correct Enrollment ID","Value Invalid",JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }
        });

        percentageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentidP();
                int boxDay = getDayPresentP();

                if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (boxDay == -202){
                    JOptionPane.showMessageDialog(frame1," Present Day Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(id == INVALID){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(boxDay == INVALID){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else{
                    if(getCheckEnrollmentId(id) == true){
                        for(Student al : students){
                        if(al instanceof Regular){
                            if(al.getEnrollmentID() == id){
                                char grade = ((Regular)al).presentPercentage(boxDay);
                                JOptionPane.showMessageDialog(frame1, "Grade "+ grade, "Grade", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    }
                }
                else{
                    JOptionPane.showMessageDialog(frame1," Invalid Enrollment id","Value Invalid",JOptionPane.ERROR_MESSAGE);
                }
                    
                }
            }
        });

        grantCertificateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentidG();
                String coursename = getCourseNameG();
                String date = getDateOfEnrollmentG();
                if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(coursename.isEmpty()){
                     JOptionPane.showMessageDialog(frame1," Course name Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(date.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," DOe  Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(id == INVALID){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                if(getCheckEnrollmentId(id) == true ){
                    for(Student al : students){
                    if(al instanceof Regular){
                        if(al.getEnrollmentID() == id ){
                            ((Regular)al).grantCertificate(coursename, id, date);
                        }
                    }
                }
                }
                else{
                        JOptionPane.showMessageDialog(frame1,"Please Enter Correct Enrollment ID ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                
            }
        });

        displayR.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent event){
                 for(Student al : students){
                    if(al instanceof Regular){
                        ((Regular)al).display();
                    }
                }
            }
        });

        clearButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                idPField.setText("");
                idGField.setText("");
                dayPresentPField.setText("");
                dayPresentField1.setText("");
                numOfModuleField.setText("");
                creditHourField.setText("");
                courseNameGField.setText("");
                enrollYearG.setSelectedItem("Year");
                enrollMonthG.setSelectedItem("Month");
                enrollDayG.setSelectedItem("Day");
            }
        });

        frame2.setVisible(true);
       }
public void makeDropout()
{
        String[] boxYear = {"Year","1998","1999","2000","2001","2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"};
        String[] boxMonth = {"Month","Jan", "Feb", "March", "April","May", "June", "July","Aug","sep","oct","Nov", "Dec"};
        String[] boxDay = {"Day","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
        
        frame3 = new JFrame("Dropout ");
        frame3.getContentPane().setBackground(Color.BLUE);
        frame3.setLayout(null);
        frame3.setSize(600, 450);
        frame3.setLocation(500, 350);
        
        remainingmoduleLabel = new JLabel("Remaing module ");
        remainingmoduleLabel.setBounds(5, 20, 110, 30);
        remainingmoduleLabel.setFont(new Font(null,0, 13));
        frame3.add(remainingmoduleLabel);

        remainingMOdyleField = new JTextField();
        remainingMOdyleField.setBounds(110, 20, 150, 30);
        frame3.add(remainingMOdyleField);

        monthattendLabel = new JLabel("Month Attended ");
        monthattendLabel.setBounds(300, 20, 110, 30);
        monthattendLabel.setFont(new Font(null,0, 13));
        frame3.add(monthattendLabel);

        numMonthAttendField = new JTextField();
        numMonthAttendField.setBounds(400, 20, 150, 30);
        frame3.add(numMonthAttendField);

        dropdateLabel = new JLabel("DOD ");
        dropdateLabel.setBounds(5, 70, 40, 30);
        dropdateLabel.setFont(new Font(null,0,13));        
        frame3.add(dropdateLabel);

        dropYear = new JComboBox<String>(boxYear);
        dropYear.setBounds(110, 70,60, 30);
        frame3.add(dropYear);

        dropMonth = new JComboBox<String>(boxMonth);
        dropMonth.setBounds(175, 70, 70, 30);
        frame3.add(dropMonth);
        dropDay = new JComboBox<String>(boxDay);
        dropDay.setBounds(255, 70, 60, 30);
        frame3.add(dropDay);

        buttonDropout = new JButton("Add Dropout ");
        buttonDropout.setBounds(5, 120, 110, 30);
        frame3.add(buttonDropout);

        JLabel line = new JLabel();
        line.setText("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        line.setBounds(0, 170, 600, 10);
        frame3.add(line);

        enrollmentLabel = new JLabel("Enrollment id ");
        enrollmentLabel.setBounds(5, 190, 80, 30);
        enrollmentLabel.setFont(new Font(null, 0, 13));
        frame3.add(enrollmentLabel);

        idBField = new JTextField();
        idBField.setBounds(95, 190, 100, 30);
        frame3.add(idBField);

        paybillButton = new JButton("Bills ");
        paybillButton.setBounds(260, 190, 80, 30);
        frame3.add(paybillButton);
        paybillButton.setEnabled(false);

        JLabel line2 = new JLabel();
        line2.setText("-------------------------------------------------------------------------------------------------------------------------------------------------------");
        line2.setBounds(0, 250, 600, 10);
        frame3.add(line2);

        enrollmentLabel = new JLabel("Enrollment id ");
        enrollmentLabel.setBounds(5, 290, 80, 30);
        enrollmentLabel.setFont(new Font(null, 0, 13));
        frame3.add(enrollmentLabel);

        idREField = new JTextField();
        idREField.setBounds(95, 290, 100, 30);
        frame3.add(idREField);

        removestudentButton = new JButton("Remove ");
        removestudentButton.setBounds(260, 290, 100, 30);
        frame3.add(removestudentButton);
        removestudentButton.setEnabled(false);
        
        displayD = new JButton("Display ");
        displayD.setBounds(95, 340, 100, 30);
        frame3.add(displayD);
        displayD.setEnabled(false);
        
        clearButton3 = new JButton("Clear");
        clearButton3.setBounds(200, 340, 100, 30);
        frame3.add(clearButton3);

        buttonDropout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentid();
                String name = getStudentname();
                String course = getCoursename();
                int courseduration = getCourseduration();
                int tuition = getTuitionFee();
                int remaingModule = getRemaingModule();
                int monthattend = getMonthAttended();
                String date = getDateOfBirth();
                String date2 = getDateOfEnrollment();
                String date3 = getDateOfDropout();
                if(name.isEmpty()){
                    JOptionPane.showMessageDialog(frame1," student name Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(course.isEmpty()){
                   JOptionPane.showMessageDialog(frame1," Course name Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (courseduration == -202){
                    JOptionPane.showMessageDialog(frame1," Course Duration Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (tuition == -202){
                    JOptionPane.showMessageDialog(frame1," Tuition Fee Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (remaingModule == -202){
                    JOptionPane.showMessageDialog(frame1," Credit Hour Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if (monthattend == -202){
                    JOptionPane.showMessageDialog(frame1," Number Module Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(id == INVALID || courseduration == INVALID || tuition == INVALID || remaingModule == INVALID || monthattend == INVALID){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                else if(date.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," Dob  Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(date2.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," Doe  Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else if(date3.equals("empty")){
                    JOptionPane.showMessageDialog(frame1," DOd  Not selected.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                else{
                    boolean check = getCheckEnrollmentId(id);

                    if(check == false){
                        students.add(new Dropout(id, date,course,name, date2, courseduration, tuition, remaingModule, monthattend,date3));
                        JOptionPane.showMessageDialog(frame1,"Dropout Student Added.","Information",JOptionPane.INFORMATION_MESSAGE);
                        paybillButton.setEnabled(true);
                        removestudentButton.setEnabled(true);
                        displayD.setEnabled(true);
                        numMonthAttendField.setText("");
                        remainingMOdyleField.setText("");
                        idBField.setText("");
                        idREField.setText(""); 
                        birthYear.setSelectedItem("Year");
                        birthMonth.setSelectedItem("Month");
                        birthDay.setSelectedItem("Day");
                        enrollYear.setSelectedItem("year");
                        enrollMonth.setSelectedItem("Month");
                        enrollDay.setSelectedItem("Day");
                        dropYear.setSelectedItem("Yeear");
                        dropMonth.setSelectedItem("Month");
                        dropDay.setSelectedItem("Day");
                        return;
                    }
                    else{
                        JOptionPane.showMessageDialog(frame1,"Please Enter Correct Enrollment ID ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }
        });

        paybillButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentidB();
               if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                 else if (id == INVALID ){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                } 
                else{
                    if(getCheckEnrollmentId(id) == true){
                        for(Student s : students){
                        if(s instanceof Dropout){
                            if(s.getEnrollmentID() == id){
                                ((Dropout)s).billsPayable();
                                return;
                            }
                        }
                    }
                    }
                    else{
                         JOptionPane.showMessageDialog(frame1," Please Enter Correct Enrollment ID","Value Invalid",JOptionPane.ERROR_MESSAGE);
                                return;
                    }
                }
                 
            }
        });

        removestudentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int id = getEnrollmentidRE();
               if(id == -202){
                    JOptionPane.showMessageDialog(frame1," Enrollmentid Empty.","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                }
                 else if (id == INVALID ){
                    JOptionPane.showMessageDialog(frame1," Please Enter Positive Value ADN Also Integer ","Value Invalid",JOptionPane.ERROR_MESSAGE);
                   return;
                } 
                else{
                    if(getCheckEnrollmentId(id) == true){
                        for(Student s : students){
                        if(s instanceof Dropout){
                            if(s.getEnrollmentID() == id){
                                ((Dropout)s).removeStudent();
                                return;
                            }
                        }
                    }
                    }
                    else{
                         JOptionPane.showMessageDialog(frame1," Please Enter Correct Enrollment ID","Value Invalid",JOptionPane.ERROR_MESSAGE);
                                return;
                    
                    }
                }
             
            }
        });

        displayD.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event){
                 for(Student al : students){
                    if(al instanceof Dropout){
                        ((Dropout)al).display();
                    }
                }
            }
        });

        clearButton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
               numMonthAttendField.setText("");
               remainingMOdyleField.setText("");
               idBField.setText("");
               idREField.setText(""); 
               dropYear.setSelectedItem("Yeear");
               dropMonth.setSelectedItem("Month");
               dropDay.setSelectedItem("Day");
            }
        });

        frame3.setVisible(true);
    }   
    //All getter Method 
    public int getEnrollmentid()
    {
        String string = idField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        }
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
     public int getEnrollmentidRE()
    {
        String string = idREField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getEnrollmentidP()
    {
        String string = idPField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        }
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getEnrollmentidG()
    {
        String string = idGField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        }
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getEnrollmentidB()
    {
        String string = idBField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public String getDateOfEnrollment()
    {
        String year = enrollYear.getSelectedItem().toString();
        String boxMonth = enrollMonth.getSelectedItem().toString();
        String boxDay = enrollDay.getSelectedItem().toString();

        if(year.equals("Year")){
            return "empty";
        }
        else if(boxMonth.equals("Month")){
            return "empty";
        }
        else if(boxDay.equals("Day")){
            return "empty";
        }
        else{
            String date = year + boxMonth + boxDay;
            return date;
        }
    }
   
    public String getStudentname()
    {
        String string = nameField.getText().trim();
        
        return string;
    }
    public int getNumModule()
    {
        String string = numOfModuleField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public String getCourseNameG()
    {
        String string = courseNameGField.getText().trim();

        return string;
    }
    public int getTuitionFee()
    {
        String string = tuitonField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getCourseduration()
    {
        String string = courseDurationField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
     public String getCoursename()
    {
        String string = courseNameField.getText().trim();

        return string;
    }

    public int getDaypresent()
    {
        String string = dayPresentField1.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getDayPresentP()
    {
        String string = dayPresentPField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getRemaingModule()
    {
        String string = remainingMOdyleField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getCreditHours()
    {
        String string = creditHourField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public int getMonthAttended()
    {
        String string = numMonthAttendField.getText().trim();
        int integer = INVALID;
        if(string.isEmpty()){
            integer = -202;

        } 
        try {
            integer = Integer.parseInt(string);
            if(integer <= 0)
            {
                integer = INVALID;
            } 
        } catch (Exception e) {
            
        }
        return integer;
    }
    public String getDateOfBirth()
    {
        String boxYear = birthYear.getSelectedItem().toString();
        String boxMonth = birthMonth.getSelectedItem().toString();
        String boxDay = birthDay.getSelectedItem().toString();

        if(boxYear.equals("Year")){
            return "empty";
        }
        else if(boxMonth.equals("Month")){
            return "empty";
        }
        else if(boxDay.equals("Day")){
            return "empty";
        }
        else{
            String date = boxYear + boxMonth + boxDay;
            return date;
        }
    }
    
    public String getDateOfEnrollmentG()
    {
       String year = enrollYearG.getSelectedItem().toString();
        String boxMonth = enrollMonthG.getSelectedItem().toString();
        String boxDay = enrollDayG.getSelectedItem().toString();

        if(year.equals("Year")){
            return "empty";
        }
        else if(boxMonth.equals("Month")){
            return "empty";
        }
        else if(boxDay.equals("Day")){
            return "empty";
        }
        else{
            String date = year + boxMonth + boxDay;
            return date;
        }
    }
    public String getDateOfDropout()
    {
        String year = dropYear.getSelectedItem().toString();
        String boxMonth = dropMonth.getSelectedItem().toString();
        String boxDay = dropDay.getSelectedItem().toString();

        if(year.equals("Year")){
            return "empty";
        }
        else if(boxMonth.equals("Month")){
            return "empty";
        }
        else if(boxDay.equals("Day")){
            return "empty";
        }
        else{
            String date = year + boxMonth + boxDay;
            return date;
        }
    }

    public boolean getCheckEnrollmentId(int enrollment)
    {
        boolean check = false;

        for (Student al : students){
            if(al instanceof Regular){
                if(al.getEnrollmentID() == enrollment){
                    check = true;
                }
            }
            if(al instanceof Dropout){
                 if(al instanceof Dropout){
                if(al.getEnrollmentID() == enrollment){
                    check = true;
                }
            }
            }
        }
        return check;
    }
    //Main Ho Hai
    public static void main(String[] args) {
        StudentGUI student = new StudentGUI();
    
        student.frame1.setVisible(true);
    }
}
