
/**
 * Write a description of class Regular here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Regular extends Student
{    // instance Variable
    private int numOfModules;
    private int numOfCreditHours;
    private double daysPresent;
    private boolean isGrantedScholarship;
    
    public Regular(int enrollmentID,String dateOfBirth,String studentName,String dateOfEnrollment, 
      String courseName,int tuitionFee,int numOfModules, int courseDuration, 
      int numOfCreditHours, double daysPresent)
    {
        super(dateOfBirth, studentName, courseDuration, tuitionFee);
        super.setEnrollmentID(enrollmentID);
        super.setDateOfEnrollment(dateOfEnrollment);
        super.setCourseName(courseName);
        this.numOfModules = numOfCreditHours;
        this.daysPresent = daysPresent;
        this.isGrantedScholarship = false;
        
    }
    //Inserting Getter method 
    public int getNumOfModules() {
        return numOfModules;
    }
    //inserting setter method in NumOfModules
    public void setNumOfModules(int numOfModules){
        this.numOfModules = numOfModules;
    }
    //inserting setter method in CreditHours
    public int getNumOfCreditHours(){
        return numOfCreditHours;
    }
    //inserting setter method value in Credithours
    public void setNumOfCreditHours(){
        this.numOfCreditHours = numOfCreditHours;
    }
    //inserting setter method in DaysPresent
    public double getDaysPresent(){
        return daysPresent;
    }
    //inserting setter method value in daysPresent
    public void setDaysPresent(double daysPresent){
        this.daysPresent = daysPresent;
    }
    //inserting getter method in GrantedScholarship
    public boolean getIsGrantedScholarship(){
        return isGrantedScholarship;
    }
    
    public char presentPercentage(double daysPresent){
        this.daysPresent = daysPresent;
        double presentPercentage = (daysPresent / (getCourseDuration()* 30)) * 100;
        char percentage = ' ';
        //applying Conditional-statement 
        if (presentPercentage >= 80 && presentPercentage<=100) {
            isGrantedScholarship = true;
            return 'A';
        }
        else if (presentPercentage >= 79 && presentPercentage <=60 ){
            isGrantedScholarship = false;
            return 'B';
        }
        else if (presentPercentage <=59 && presentPercentage >= 40){
            isGrantedScholarship = false;
            return 'C';
        }
         else if (presentPercentage <= 39 && presentPercentage >= 20) {
            isGrantedScholarship = false;
            return 'D';
        } 
        else if(presentPercentage < 20){
            isGrantedScholarship = false;
            return 'E';
        }
        return percentage;
        
    }
    public void grantCertificate(String courseName,int enrollmentID, String dateOfEnrollment){
        System.out.println(getStudentName() + " Has Graduated In" + courseName + " with Enrollment ID"
         + enrollmentID + " and date of enrollment " + dateOfEnrollment + ".");
         //conditional statement
         if(isGrantedScholarship == true) {
             System.out.println("The Scholarship Has Been Granted.");
         }
    }
    //Displaying the values
    public void displayDetails() {
        System.out.println("Enrollment ID: " + getEnrollmentID());
        System.out.println("Student Name: " + getStudentName());
        System.out.println("Date of Birth: " + getDateOfBirth());
        System.out.println("Course Name: " + getCourseName());
        System.out.println("Date of Enrollment: " + getDateOfEnrollment());
        System.out.println("Course Duration: " + getCourseDuration());
        System.out.println("TuitionFee: " + getTuitionFee());
        System.out.println("Number of Modules: " + getNumOfModules());
         System.out.println("Number Of CreditHours: " + getNumOfCreditHours());
        System.out.println("Days Present: " + getDaysPresent());
        System.out.println("Scholarship Granted: " + isGrantedScholarship);
    }
    
    
    
}
