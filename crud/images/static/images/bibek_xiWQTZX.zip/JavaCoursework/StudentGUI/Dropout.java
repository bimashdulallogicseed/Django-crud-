
/**
 * Write a description of class Dropout here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dropout extends Student
{
    // Instance variable
    int numOfRemainingModules;
    int numOfMonthsAttended;
    String dateOfDropout;
    int remainingAmount;
    boolean hasPaid;
    //creating the Dropout with parameter value
    public Dropout(int id, String studentName, String course, 
     String name, String date2, int numOfMonthsAttended, int
      tuition, int enrollmentID, int monthattend,String dateOfEnrollment )
    {
        super(id,studentName,course,name);
        super.setCourseName(monthattend);
        super.setDateOfEnrollment(dateOfEnrollment);
        super.setEnrollmentID(enrollmentID);
        this.numOfMonthsAttended = numOfMonthsAttended;
        this.dateOfDropout = tuition;
        this.remainingAmount = 0;
        this.hasPaid = false;
        
    }
    // Inserting getter method in NumOfRemainingModules
    public int getNumOfRemainingModules(){
        return this.numOfRemainingModules;
    }
    //Inserting getter method in NumOfAttended
    public int getNumOfMonthsAttended(){
        return this.numOfMonthsAttended;
    }
    //Inserting getter method in RemainingAmount
    public int getRemainingAmount(){
        return this.remainingAmount;
    }
    
    public boolean getHasPaid()
    {
        return this.hasPaid;
    }
    //creating new method with return type void
    public void billsPayable(){
        if(hasPaid == false)
        {
          if(super.getCourseDuration() >=numOfMonthsAttended)
           {
            this. remainingAmount = (super.getCourseDuration() - numOfMonthsAttended)* super.getTuitionFee();
            this.hasPaid = true;
             System.out.println(this.remainingAmount);//Printing remaining amount when hasPaid is true
           }
           else
          {
            System.out.println("Remaining amount cannot be calculated");
          }
        }
        else{
            System.out.println("Bills is already cleared");
        }
    }
     public void removeStudent()
     {
    //Conditional-statement
     if(hasPaid == true)
        {
            super.setDateOfBirth("");
            super.setStudentName("");
            super.setCourseDuration(0);
            super.setCourseName("");
            this.setDateOfEnrollment("");
            this.dateOfDropout = "";
            this.setTuitionFee(0);
            this.setEnrollmentID(0);
            this.numOfRemainingModules = 0;
            this.numOfMonthsAttended=0;
            this.remainingAmount = 0;
            this.hasPaid = false;
        }
     else{
            System.out.println("All bills aren't cleared"); //Printing from removeStudent when hasPaid is qual to true 
    }
    }
    //displaying the value with super class
    public void display()
    {
        super.display();
        System.out.println("numOfRemainingModules: " + numOfRemainingModules);
        System.out.println("numOfMonthsAttended: " + numOfMonthsAttended);
        System.out.println("dateOfDropout: " + dateOfDropout);
        System.out.println("remainingAmount: " + remainingAmount);
        System.out.println("hasPaid: " + hasPaid);
        
    }
}
